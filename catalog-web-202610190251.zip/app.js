/* أسعار المنتجات — delegate price catalog (Alpine.js, no build step).
 *
 * A separate app from the owner stats app in ../pwa: its own config global
 * (TAQSEET_CATALOG_CONFIG), its own localStorage keys (all prefixed "tqcat.") and its own
 * service-worker cache (tqcat-v1). Nothing here reads or writes the stats app's state.
 *
 * Demo mode for local checks: ?demo=1 reads ./demo-catalog.json instead of the Worker, and
 * ?demo=401 | 403 | 404 | offline simulates those Worker answers. Demo mode stores under
 * "tqcat.demo." so it can never overwrite a real saved login on the same origin.
 */

const MAX_SHOWN = 200;          // cards rendered at once; the rest wait for a narrower search
const PULL_TRIGGER = 64;        // px of pull (after damping) that triggers a refresh
const ANIMATED_CARDS = 12;      // cards that replay the fade-up after a search; the rest are off-screen
const PULL_MAX = 96;

const DEMO = new URLSearchParams(location.search).get("demo") || "";
const KEY_PREFIX = DEMO ? "tqcat.demo." : "tqcat.";
const KEYS = {
  user: KEY_PREFIX + "user",
  pass: KEY_PREFIX + "pass",
  data: KEY_PREFIX + "data",
};

const MSG_REVOKED = "الباسورد اتغير أو الحساب اتلغى، ادخل تاني";
const MSG_BAD_LOGIN = "اسم المستخدم أو الباسورد غلط";

function store(key, value) {
  try {
    if (value === null) localStorage.removeItem(key);
    else localStorage.setItem(key, value);
  } catch (e) { /* storage full or blocked: the app still works for this session */ }
}
function load(key) {
  try { return localStorage.getItem(key); } catch (e) { return null; }
}

/* The catalog sorted once per fetch. Kept outside Alpine's reactive state on purpose:
   ~3000 items wrapped in reactive proxies would make every keystroke's filter slower. */
const collator = new Intl.Collator("ar");
let allItems = [];
function setItems(items) {
  allItems = (Array.isArray(items) ? items : [])
    .filter((it) => it && it.name)
    .slice()
    .sort((a, b) => collator.compare(String(a.name), String(b.name)));
}

/** One GET to the catalog Worker. Resolves to { kind, data? }, never throws:
 *  ok | unauthorized | disabled | empty | http (other status) | network (no answer). */
async function fetchCatalog(cfg, username, password) {
  if (DEMO) return demoFetch();
  if (!cfg.workerUrl) return { kind: "http", status: "config" };
  let res;
  try {
    res = await fetch(cfg.workerUrl, {
      // Username may be Arabic → URL-encode it so it survives the latin-1 header.
      headers: { "X-Username": encodeURIComponent(username), "X-Access-Token": password },
      cache: "no-store",
    });
  } catch (e) {
    return { kind: "network" };
  }
  return readResponse(res);
}

async function readResponse(res) {
  let body = null;
  try { body = await res.json(); } catch (e) { /* non-JSON body */ }
  if (res.status === 200 && body) return { kind: "ok", data: body };
  if (res.status === 401) return { kind: "unauthorized" };
  if (res.status === 403 && body && body.error === "disabled") return { kind: "disabled" };
  if (res.status === 404 && body && body.error === "no_catalog") return { kind: "empty" };
  return { kind: "http", status: res.status };
}

async function demoFetch() {
  if (DEMO === "offline") return { kind: "network" };
  if (DEMO === "401") return { kind: "unauthorized" };
  if (DEMO === "403") return { kind: "disabled" };
  if (DEMO === "404") return { kind: "empty" };
  try {
    const res = await fetch("demo-catalog.json?t=" + Date.now(), { cache: "no-store" });
    return readResponse(res);
  } catch (e) {
    return { kind: "network" };
  }
}

document.addEventListener("alpine:init", () => {
  Alpine.data("catalog", () => ({
    cfg: window.TAQSEET_CATALOG_CONFIG || {},
    screen: "login",        // login | app
    block: "",              // "" | disabled | empty
    loading: false,
    loginUser: "",
    loginPass: "",
    loginErr: "",
    showPass: false,
    company: "",
    currency: "ج.م",
    generatedAt: "",
    offlineMsg: "",
    stateErr: "",
    query: "",
    shown: [],
    matchCount: 0,
    hasItems: false,
    pull: 0,
    pulled: false,
    pullTrigger: PULL_TRIGGER,

    init() {
      const cached = load(KEYS.data);
      if (cached) {
        try { this.applyData(JSON.parse(cached)); } catch (e) { store(KEYS.data, null); }
      }
      if (load(KEYS.user) && load(KEYS.pass)) {
        this.screen = "app";
        this.refresh();
      }
      this.setupPullToRefresh();
      if ("serviceWorker" in navigator) {
        navigator.serviceWorker.register("sw.js").catch(() => {});
      }
      // Android app: tells the web code push this bundle started, so it is kept (WebUpdate.java).
      if (window.TqNative) window.TqNative.bootOk();
    },

    /* First login: the credentials are saved only once the Worker accepts them. */
    async submitLogin() {
      const u = (this.loginUser || "").trim();
      const p = (this.loginPass || "").trim();
      if (!u) { this.loginErr = "اكتب اسم المستخدم"; return; }
      if (!p) { this.loginErr = "اكتب الباسورد"; return; }
      this.loginErr = "";
      this.loading = true;
      const result = await fetchCatalog(this.cfg, u, p);
      this.loading = false;
      if (result.kind === "unauthorized") { this.loginErr = MSG_BAD_LOGIN; return; }
      if (result.kind === "network") { this.loginErr = "مفيش نت، جرّب تاني"; return; }
      if (result.kind === "http") { this.loginErr = "السيرفر مش بيرد دلوقتي (" + result.status + ")"; return; }
      // ok / disabled / empty all mean the login itself is valid → keep it forever.
      store(KEYS.user, u);
      store(KEYS.pass, p);
      this.loginPass = "";
      this.showPass = false;
      this.screen = "app";
      this.handle(result);
    },

    /* Sign out on this phone: forget the saved password and prices, keep the username typed in. */
    logout() {
      const u = load(KEYS.user) || "";
      store(KEYS.user, null);
      store(KEYS.pass, null);
      store(KEYS.data, null);
      this.applyData(null);
      this.block = "";
      this.offlineMsg = "";
      this.stateErr = "";
      this.query = "";
      this.loginUser = u;
      this.loginPass = "";
      this.showPass = false;
      this.loginErr = "";
      this.screen = "login";
    },

    /* Re-fetch with the saved login: on open, on pull-to-refresh and from the ↻ button. */
    async refresh() {
      const u = load(KEYS.user);
      const p = load(KEYS.pass);
      if (!u || !p) { this.screen = "login"; return; }
      if (this.loading) return;
      this.loading = true;
      try {
        this.handle(await fetchCatalog(this.cfg, u, p));
      } finally {
        this.loading = false;
        this.pulled = false;
      }
    },

    handle(result) {
      this.stateErr = "";
      switch (result.kind) {
        case "ok":
          this.offlineMsg = "";
          if (result.data.enabled === false) { this.block = "disabled"; return; }
          this.block = "";
          store(KEYS.data, JSON.stringify(result.data));
          this.applyData(result.data);
          return;
        case "unauthorized":
          // Password changed or account removed: forget everything but the username, back to login.
          this.loginUser = load(KEYS.user) || "";
          store(KEYS.user, null);
          store(KEYS.pass, null);
          store(KEYS.data, null);
          this.applyData(null);
          this.block = "";
          this.offlineMsg = "";
          this.loginErr = MSG_REVOKED;
          this.screen = "login";
          return;
        case "disabled":
          this.block = "disabled";   // login kept; checked again on the next open/refresh
          return;
        case "empty":
          this.block = "empty";
          this.offlineMsg = "";
          this.applyData(null);
          return;
        case "network":
          this.block = "";
          if (this.hasItems) {
            this.offlineMsg = "من غير نت — آخر تحديث " + this.formatDate(this.generatedAt);
          } else {
            this.stateErr = "من غير نت ومفيش أسعار محفوظة، اتصل بالنت واسحب لتحت للتحديث";
          }
          return;
        default:
          this.block = "";
          if (this.hasItems) {
            this.offlineMsg = "تعذّر التحديث — آخر تحديث " + this.formatDate(this.generatedAt);
          } else {
            this.stateErr = "تعذّر تحميل الأسعار (" + result.status + ")، اسحب لتحت وجرّب تاني";
          }
      }
    },

    applyData(d) {
      this.company = (d && d.company) || "";
      this.currency = (d && d.currency) || "ج.م";
      this.generatedAt = (d && d.generatedAt) || "";
      setItems(d && d.items);
      this.hasItems = allItems.length > 0;
      this.applySearch();
    },

    /* Called from the search box through Alpine's 120 ms debounce. */
    applySearch() {
      const matches = window.TqcatSearch.filterItems(allItems, this.query);
      this.matchCount = matches.length;
      this.shown = matches.slice(0, MAX_SHOWN);
      this.$nextTick(() => this.animateResults());
    },

    /* Every search change replays a short fade-up on the visible cards and a pulse on the
       count, so the delegate sees that the list changed even when the first card is the same. */
    animateResults() {
      if (!Element.prototype.animate) return;
      if (window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
      const cards = this.$root.querySelectorAll(".items > .item");
      cards.forEach((el, i) => {
        el.getAnimations().forEach((a) => a.cancel());
        if (i >= ANIMATED_CARDS) return;
        el.animate(
          [{ opacity: 0, transform: "translateY(12px)" }, { opacity: 1, transform: "none" }],
          { duration: 240, delay: i * 40, easing: "cubic-bezier(.2,.8,.2,1)", fill: "backwards" });
      });
      const count = this.$root.querySelector(".count");
      if (count) {
        count.getAnimations().forEach((a) => a.cancel());
        count.animate([{ transform: "scale(1.18)" }, { transform: "scale(1)" }],
          { duration: 260, easing: "ease-out" });
      }
    },

    get hiddenCount() { return Math.max(0, this.matchCount - this.shown.length); },

    countLabel() {
      const n = this.matchCount.toLocaleString("en-US");
      return this.query ? n + " نتيجة" : n + " صنف";
    },

    money(v) {
      return this.num(v) + " " + this.currency;
    },

    /* The same figures without the currency, for the large plan numbers on a card. */
    num(v) {
      return new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(Math.round(v || 0));
    },
    /* Monthly instalment a multiple of 10 and the down payment that makes up the total
       (plan.js; owner rule 2026-10-19). */
    monthlyNum(total, months) {
      return this.num(TqcatPlan.splitPlan(total, months).monthly);
    },
    downLabel(total, months) {
      const down = TqcatPlan.splitPlan(total, months).down;
      return down > 0 ? "مقدم " + this.num(down) : "بدون مقدم";
    },

    formatDate(iso) {
      if (!iso) return "—";
      const d = new Date(iso);
      if (isNaN(d.getTime())) return String(iso);
      return new Intl.DateTimeFormat("ar-EG-u-nu-latn", {
        day: "numeric", month: "long", year: "numeric", hour: "numeric", minute: "2-digit",
      }).format(d);
    },

    /* Touch pull-to-refresh: dragging down while the page is at the very top grows the
       indicator; releasing past PULL_TRIGGER refreshes. Native browser pull-to-refresh is
       switched off in CSS (overscroll-behavior-y) so the two never fight. */
    setupPullToRefresh() {
      let startY = null;
      window.addEventListener("touchstart", (e) => {
        if (this.screen !== "app" || this.loading || window.scrollY > 0 || e.touches.length !== 1) {
          startY = null;
          return;
        }
        startY = e.touches[0].clientY;
      }, { passive: true });
      window.addEventListener("touchmove", (e) => {
        if (startY === null) return;
        const dy = e.touches[0].clientY - startY;
        if (dy <= 0 || window.scrollY > 0) { this.pull = 0; return; }
        this.pull = Math.min(PULL_MAX, Math.round(dy * 0.5));
        if (e.cancelable) e.preventDefault();   // keep the page still while pulling
      }, { passive: false });
      const end = () => {
        if (startY === null) return;
        startY = null;
        const trigger = this.pull >= PULL_TRIGGER;
        this.pull = 0;
        if (trigger) { this.pulled = true; this.refresh(); }
      };
      window.addEventListener("touchend", end, { passive: true });
      window.addEventListener("touchcancel", end, { passive: true });
    },
  }));
});
