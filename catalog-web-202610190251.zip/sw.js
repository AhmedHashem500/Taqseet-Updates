/* أسعار المنتجات — service worker: caches the app shell for offline use.
 * The catalog JSON is intentionally NOT cached here: the app fetches it live and keeps
 * its own last good copy in localStorage (tqcat.data), which it shows when offline.
 * Cache name is this app's own, so it never touches the stats app's caches. */
const CACHE = "tqcat-v8";
const SHELL = [
  "./",
  "./index.html",
  "./app.js",
  "./search.js",
  "./plan.js",
  "./config.js",
  "./styles.css",
  "./cairo.ttf",
  "./alpine.min.js",
  "./manifest.webmanifest",
  "./icon-192.png",
  "./icon-512.png"
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  // Only drop OUR older versions (tqcat-*); another app on the same origin keeps its caches.
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys
        .filter((k) => k.startsWith("tqcat-") && k !== CACHE)
        .map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  // Live data never goes through the cache: the Worker, and the local demo catalog.
  if (url.origin !== self.location.origin) return;
  if (url.pathname.endsWith("/catalog") || url.pathname.endsWith("demo-catalog.json")) return;

  // Same-origin app shell: network-first (fresh when online), cache fallback offline.
  e.respondWith(
    fetch(req).then((res) => {
      if (res.ok) {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(req, copy));
      }
      return res;
    }).catch(() => caches.match(req, { ignoreSearch: true }))
  );
});
