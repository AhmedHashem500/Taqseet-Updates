/* أسعار المنتجات — search helpers.
 *
 * Plain script, no dependencies. In the browser it attaches `window.TqcatSearch`;
 * in Node it is exported through `module.exports` so `node --test` can unit-test it.
 */
(function (root) {
  "use strict";

  // Arabic diacritics (tashkeel: fathatan … sukun, plus the extended marks up to U+065F)
  // and the superscript alef U+0670.
  var TASHKEEL = /[ً-ٰٟ]/g;
  var TATWEEL = /ـ/g;
  var ALEF_VARIANTS = /[آأإٱ]/g; // آ أ إ ٱ
  var ARABIC_INDIC_DIGITS = /[٠-٩]/g;      // ٠ … ٩
  var PERSIAN_DIGITS = /[۰-۹]/g;           // ۰ … ۹ (some keyboards emit these)
  var WHITESPACE = /\s+/g;

  /**
   * Fold a string to its search key: lower-case, no spaces, no tashkeel/tatweel,
   * one alef, ة → ه, ى → ي, and Latin digits. Two spellings a delegate would consider
   * "the same word" map to the same key.
   */
  function normalize(text) {
    if (text === null || text === undefined) return "";
    return String(text)
      .toLowerCase()
      .replace(TASHKEEL, "")
      .replace(TATWEEL, "")
      .replace(ALEF_VARIANTS, "ا")
      .replace(/ة/g, "ه") // ة → ه
      .replace(/ى/g, "ي") // ى → ي
      .replace(ARABIC_INDIC_DIGITS, function (d) { return String(d.charCodeAt(0) - 0x0660); })
      .replace(PERSIAN_DIGITS, function (d) { return String(d.charCodeAt(0) - 0x06F0); })
      .replace(WHITESPACE, "");
  }

  /** Normalized key per item, computed once (items are re-searched on every keystroke). */
  var keyCache = typeof WeakMap === "function" ? new WeakMap() : null;
  function keyOf(item) {
    if (!keyCache) return normalize(item && item.name);
    var k = keyCache.get(item);
    if (k === undefined) {
      k = normalize(item && item.name);
      keyCache.set(item, k);
    }
    return k;
  }

  /**
   * Items whose name matches the query. A match is either every space-separated word of
   * the query appearing somewhere in the name (any order), or the whole query with its
   * spaces removed appearing in the name with its spaces removed. Empty query → all items.
   */
  function filterItems(items, query) {
    var list = items || [];
    var raw = query === null || query === undefined ? "" : String(query);
    var whole = normalize(raw);
    if (!whole) return list.slice();
    var words = raw.split(WHITESPACE).map(normalize).filter(Boolean);
    return list.filter(function (item) {
      var key = keyOf(item);
      if (key.indexOf(whole) !== -1) return true;
      for (var i = 0; i < words.length; i++) {
        if (key.indexOf(words[i]) === -1) return false;
      }
      return true;
    });
  }

  var api = { normalize: normalize, filterItems: filterItems };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (root) root.TqcatSearch = api;
})(typeof window !== "undefined" ? window : null);
