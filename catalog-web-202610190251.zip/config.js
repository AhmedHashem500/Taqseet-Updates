// Delegate price catalog (أسعار المنتجات) — Worker endpoint. Not a secret.
// Template and notes: config.example.js
window.TAQSEET_CATALOG_CONFIG = {
  workerUrl: "https://taqseet-catalog.hashem-dev.workers.dev/catalog"
};
