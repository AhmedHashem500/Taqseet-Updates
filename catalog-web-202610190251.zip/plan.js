/* أسعار المنتجات — instalment plan split.
 *
 * Owner rule (2026-10-19): the monthly instalment is always a multiple of 10 pounds, rounded
 * DOWN; whatever that leaves of the plan total is the down payment (مقدم), so instalments plus
 * down payment always equal the published total exactly.
 *
 * Plain script, no dependencies. In the browser it attaches `window.TqcatPlan`;
 * in Node it is exported through `module.exports` so `node --test` can unit-test it.
 */
(function (root) {
  "use strict";

  var STEP = 10;

  function splitPlan(total, months) {
    total = Math.round(Number(total) || 0);
    if (total <= 0 || !(months > 0)) return { monthly: 0, down: 0 };
    var monthly = Math.floor(total / months / STEP) * STEP;
    // A total below months × 10 cannot carry a 10-pound instalment: fall back to whole
    // pounds (same split, step 1) rather than quoting "0 a month".
    if (monthly === 0) monthly = Math.floor(total / months);
    return { monthly: monthly, down: total - monthly * months };
  }

  var api = { splitPlan: splitPlan };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (root) root.TqcatPlan = api;
})(typeof window !== "undefined" ? window : null);
