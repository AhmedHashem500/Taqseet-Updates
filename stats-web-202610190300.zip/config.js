// ─────────────────────────────────────────────────────────────────────────
//  إعدادات تطبيق الإحصائيات
//  المستودع (taqseet-stats-data) خاص (private). التطبيق لا يتصل بـ GitHub مباشرة،
//  بل يجلب stats.json عبر بوابة Cloudflare Worker مع إرسال رمز الدخول في ترويسة
//  X-Access-Token. لا يُضمَّن أي توكن GitHub داخل التطبيق. راجع mobile/worker/SETUP.md.
// ─────────────────────────────────────────────────────────────────────────
window.TAQSEET_STATS_CONFIG = {
  // رابط الـ Worker المنشور (يُضاف /stats تلقائيًا إن لم يُذكر).
  workerUrl: "https://taqseet-stats.hashem-dev.workers.dev",

  // false = يجلب أحدث الأرقام من الـ Worker عند كل فتح (ويعرض آخر نسخة محفوظة عند عدم وجود إنترنت).
  // true  = يقرأ ملف stats.json المرفق فقط (للاختبار).
  local: false
};
