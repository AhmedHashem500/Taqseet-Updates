/* إحصائيات التقسيط — Alpine.js dashboard (no build step). */

// Read the bundled/served stats.json next to index.html. Uses XMLHttpRequest,
// not fetch(), because Android WebView blocks fetch() of file:// assets.
function readLocalStats() {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("GET", "./stats.json?t=" + Date.now());
    xhr.onload = () => {
      if (xhr.status === 200 || xhr.status === 0) { // file:// success = status 0
        try { resolve(JSON.parse(xhr.responseText)); }
        catch (e) { reject(new Error("بيانات محلية غير صالحة")); }
      } else {
        reject(new Error("لا يوجد ملف stats.json محلي"));
      }
    };
    xhr.onerror = () => reject(new Error("تعذّر قراءة البيانات المحلية"));
    xhr.send();
  });
}

/** Fetch stats.json through the Cloudflare Worker gateway, sending the access token in
 *  the X-Access-Token header. A wrong token (401) is thrown as e.code === 401 so the UI
 *  returns to the token screen; network/upstream errors fall back to the cached/bundled
 *  copy so the app still works offline. */
async function fetchStats(cfg, username, password) {
  if (cfg.local) {
    return await readLocalStats();
  }
  if (!cfg.workerUrl) {
    const e = new Error("لم يتم ضبط عنوان الخادم (workerUrl) في config.js"); e.code = "config"; throw e;
  }
  // Accept the Worker URL with or without the /stats path (and any trailing slash).
  let endpoint = cfg.workerUrl.replace(/\/+$/, "");
  if (!/\/stats$/.test(endpoint)) endpoint += "/stats";
  let res;
  try {
    res = await fetch(endpoint, {
      // Username may be Arabic → URL-encode it so it survives the latin-1 header.
      headers: { "X-Username": encodeURIComponent(username || ""), "X-Access-Token": password || "" },
      cache: "no-store",
    });
  } catch (netErr) {
    // Offline / unreachable → fall back to the last cached/bundled copy if any.
    try { return await readLocalStats(); } catch (e2) { throw netErr; }
  }
  if (res.status === 401) {
    const e = new Error("اسم المستخدم أو كلمة المرور غير صحيحة"); e.code = 401; throw e;
  }
  if (!res.ok) {
    const e = new Error("HTTP " + res.status);
    try { return await readLocalStats(); } catch (e2) { throw e; }
  }
  return await res.json();
}

/** Merge a set of monthly periods into one aggregate view (year / all-time). */
const PROFIT_KEYS = ["finishedTahseel", "unfinishedTahseel", "totalRemainTahseel", "totalCash",
  "firstPaid", "mandoubSelling", "mandoubTahseel", "purchasePrice", "totalTaqseetSelling",
  "cashProfits", "cashProfitsNoMandoub", "taqseetProfits", "taqseetProfitsNoMandoub"];

function aggregate(periods) {
  const t = { total: 0, remaining: 0, completed: 0, cash: 0, down: 0 };
  const byName = {};
  const pf = {};
  PROFIT_KEYS.forEach(k => pf[k] = 0);
  let remainSnap = 0;
  for (const p of periods) {
    for (const k in t) t[k] += (p.tahseel && p.tahseel[k]) || 0;
    for (const m of (p.mandobs || [])) byName[m.name] = (byName[m.name] || 0) + m.share;
    const pp = p.profit || {};
    for (const k of PROFIT_KEYS) {
      if (k !== "totalRemainTahseel") pf[k] += pp[k] || 0;
    }
    if (pp.totalRemainTahseel) remainSnap = pp.totalRemainTahseel; // all-time snapshot, not summed
  }
  pf.totalRemainTahseel = remainSnap;
  pf.net = pf.cashProfitsNoMandoub + pf.taqseetProfitsNoMandoub;
  pf.totalSales = pf.totalCash + pf.totalTaqseetSelling;
  pf.mandoubTotal = pf.mandoubSelling + pf.mandoubTahseel;
  pf.margin = pf.totalSales > 0 ? (pf.net / pf.totalSales * 100) : 0;

  const mandobs = Object.keys(byName)
    .map(name => ({ name, share: byName[name] }))
    .sort((a, b) => b.share - a.share);
  const mandobTotal = mandobs.reduce((s, m) => s + m.share, 0);
  return { tahseel: t, mandobs, mandobTotal, profit: pf, empty: false };
}

document.addEventListener("alpine:init", () => {
  Alpine.data("stats", () => ({
    loading: false,
    error: "",
    data: null,
    selYear: "all",
    selMonth: "all",
    authed: false,
    username: "",
    password: "",
    authErr: "",
    mustChange: false,   // server signals the starter password must be replaced
    showChange: false,   // user opened the change screen from settings
    newToken: "",
    newToken2: "",
    changeErr: "",
    changing: false,
    _selDone: false,
    cfg: window.TAQSEET_STATS_CONFIG || {},
    profitRows: [
      { k: "net", label: "صافي الربح النهائي", desc: "إجمالي ربح الفترة بعد خصم كل التكاليف وعمولات المناديب", head: true },
      { k: "totalSales", label: "إجمالي المبيعات", desc: "مبيعات الكاش + التقسيط في الفترة" },
      { k: "margin", label: "هامش صافي الربح", desc: "نسبة صافي الربح من إجمالي المبيعات", pct: true },
      { k: "mandoubTotal", label: "إجمالي عمولات المناديب", desc: "مكافآت البيع + نسب التحصيل" },
      { k: "finishedTahseel", label: "التحصيل المكتمل", desc: "أقساط تم تحصيلها فعلاً" },
      { k: "unfinishedTahseel", label: "التحصيل المتبقي", desc: "أقساط مستحقة لم تُحصّل بعد" },
      { k: "totalRemainTahseel", label: "التحصيل الكلي المتبقي", desc: "كل الأقساط غير المحصّلة (كل الوقت)" },
      { k: "totalCash", label: "إجمالي مبيعات الكاش", desc: "قيمة المبيعات النقدية" },
      { k: "totalTaqseetSelling", label: "إجمالي مبيعات التقسيط", desc: "قيمة مبيعات التقسيط" },
      { k: "firstPaid", label: "إجمالي المقدمات", desc: "المبالغ المقدمة من عملاء التقسيط" },
      { k: "purchasePrice", label: "سعر شراء البضاعة المباعة", desc: "تكلفة شراء البضاعة المباعة" },
      { k: "mandoubSelling", label: "مكافآت البيع للمناديب", desc: "عمولات المناديب على البيع" },
      { k: "mandoubTahseel", label: "نسبة التحصيل للمناديب", desc: "عمولات المناديب على التحصيل" },
      { k: "cashProfits", label: "أرباح مبيعات الكاش", desc: "ربح الكاش = البيع − الشراء" },
      { k: "cashProfitsNoMandoub", label: "أرباح الكاش بدون نسب المناديب", desc: "بعد خصم عمولات المناديب" },
      { k: "taqseetProfits", label: "أرباح مبيعات التقسيط", desc: "ربح التقسيط = البيع − الشراء" },
      { k: "taqseetProfitsNoMandoub", label: "أرباح التقسيط بدون المستحقات", desc: "بعد خصم عمولات ومستحقات المناديب" }
    ],

    init() {
      this.username = localStorage.getItem("taqseet-username") || ""; // remembered, editable
      this.password = "";                          // never remembered — login is required each launch
      this.authed = false;
      // Load the last cached copy so the dashboard paints instantly AFTER a successful login.
      const cached = localStorage.getItem("taqseet-stats");
      if (cached) {
        try { this.data = JSON.parse(cached); } catch (e) { /* ignore */ }
      }
      if (this.cfg.local) {                        // bundled/testing mode: no login gate
        this.authed = true;
        if (this.data) this.$nextTick(() => this.initSelection());
        this.refresh();
      }
      if ("serviceWorker" in navigator) {
        navigator.serviceWorker.register("sw.js").catch(() => {});
      }
      // Android app: tells the web code push this bundle started, so it is kept (WebUpdate.java).
      if (window.TqNative) window.TqNative.bootOk();
    },

    /* Save the entered username + password and validate them against the Worker (via refresh). */
    submitLogin() {
      const u = (this.username || "").trim();
      const p = (this.password || "").trim();
      if (!u) { this.authErr = "أدخل اسم المستخدم"; return; }
      if (!p) { this.authErr = "أدخل كلمة المرور"; return; }
      this.username = u;
      this.password = p;
      localStorage.setItem("taqseet-username", u); // remember the username (editable next launch)
      // password is intentionally NOT persisted — it must be re-entered every launch
      this.authErr = "";
      this.refresh(); // authed=true on success, or authed=false + authErr on bad credentials (401)
    },

    logout() {
      // Username stays remembered (editable); clear the password + session.
      this.password = "";
      this.authed = false;
      this.authErr = "";
    },

    /* Change the access token via the Worker (POST /auth/change). Used both for the forced
       first-login change (mustChange) and the voluntary Settings change. */
    async changeToken() {
      const a = (this.newToken || "").trim();
      const b = (this.newToken2 || "").trim();
      if (!a) { this.changeErr = "أدخل الرمز الجديد"; return; }
      if (a !== b) { this.changeErr = "الرمزان غير متطابقين"; return; }
      this.changing = true;
      this.changeErr = "";
      try {
        const base = (this.cfg.workerUrl || "").replace(/\/+$/, "").replace(/\/stats$/, "");
        const res = await fetch(base + "/auth/change", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ username: this.username, current: this.password, new: a }),
        });
        if (!res.ok) {
          let msg = "تعذّر تغيير كلمة المرور";
          try { const j = await res.json(); if (j && j.error) msg = j.error; } catch (e) { /* keep default */ }
          this.changeErr = msg;
          return;
        }
        // Success: adopt the new password everywhere.
        this.password = a;   // in-memory for this session only (not persisted)
        this.newToken = "";
        this.newToken2 = "";
        this.mustChange = false;
        this.showChange = false;
        this.changeErr = "";
        await this.refresh();
      } catch (e) {
        this.changeErr = "تعذّر الاتصال بالخادم";
      } finally {
        this.changing = false;
      }
    },

    // Master switch published by the admin: enabled === false → block the whole app.
    get appDisabled() { return !!(this.data && this.data.enabled === false); },

    async refresh() {
      if ((!this.username || !this.password) && !this.cfg.local) { this.authed = false; return; }
      this.loading = true;
      this.error = "";
      try {
        const d = await fetchStats(this.cfg, this.username, this.password);
        this.data = d;
        localStorage.setItem("taqseet-stats", JSON.stringify(d));
        this.authed = true;                        // credentials accepted by the Worker
        this.authErr = "";
        this.mustChange = !!(d && d.mustChange);   // still on the starter password → force a change
        this.$nextTick(() => this.initSelection());
      } catch (e) {
        if (e.code === 401) {                      // bad credentials → back to the login screen
          this.authed = false;
          this.password = "";
          this.authErr = "اسم المستخدم أو كلمة المرور غير صحيحة";
        } else {
          this.error = (this.data ? "تعذّر التحديث (عرض آخر نسخة محفوظة): " : "") + e.message;
        }
      } finally {
        this.loading = false;
      }
    },

    /* selection default: the CURRENT calendar month/year (falls back to the
       latest available period if the current one has no data). A valid manual
       selection is preserved across refreshes. */
    initSelection() {
      const ys = this.years;
      if (!ys.length) return;
      // Keep an already-valid user selection across refreshes.
      if (this._selDone && this.selYear !== "all" && ys.includes(+this.selYear)) {
        const cur = this.monthsFor(this.selYear);
        if (this.selMonth === "all" || cur.includes(+this.selMonth)) return;
      }
      const now = new Date();
      const cy = now.getFullYear();
      const cm = now.getMonth() + 1;
      if (ys.includes(cy)) {
        this.selYear = String(cy);
        const ms = this.monthsFor(cy);
        this.selMonth = ms.includes(cm) ? String(cm) : (ms.length ? String(ms[ms.length - 1]) : "all");
      } else {
        // current year has no data → latest available year + its latest month
        this.selYear = String(ys[0]);
        const ms = this.monthsFor(this.selYear);
        this.selMonth = ms.length ? String(ms[ms.length - 1]) : "all";
      }
      this._selDone = true;
    },
    onYearChange() {
      if (this.selYear === "all") { this.selMonth = "all"; return; }
      const ms = this.monthsFor(this.selYear);
      this.selMonth = ms.length ? String(ms[ms.length - 1]) : "all";
    },

    // Which periods are visible everywhere (dropdowns + "all" aggregates). Future
    // months are always hidden. The CURRENT month is hidden during days 1–24 (its
    // collection isn't complete yet) and only shows from day 25 onward.
    get periods() {
      const all = (this.data && this.data.periods) || [];
      const now = new Date();
      let ly = now.getFullYear();
      let lm = now.getMonth() + 1;           // latest allowed month
      if (now.getDate() <= 24) {             // days 1–24 → hide the current month
        lm -= 1;
        if (lm === 0) { lm = 12; ly -= 1; }
      }
      return all.filter(p => p.year < ly || (p.year === ly && p.month <= lm));
    },
    get years() {
      const s = [...new Set(this.periods.map(p => p.year))];
      s.sort((a, b) => b - a);
      return s;
    },
    monthsFor(y) {
      const yy = +y;
      const s = [...new Set(this.periods.filter(p => p.year === yy).map(p => p.month))];
      s.sort((a, b) => a - b);
      return s;
    },
    get monthsForYear() { return this.selYear === "all" ? [] : this.monthsFor(this.selYear); },

    get view() {
      if (!this.data) return null;
      let sel = this.periods;
      if (this.selYear !== "all") sel = sel.filter(p => p.year === +this.selYear);
      if (this.selYear !== "all" && this.selMonth !== "all") sel = sel.filter(p => p.month === +this.selMonth);
      if (!sel.length) {
        return { empty: true, tahseel: { total: 0, remaining: 0, completed: 0, cash: 0, down: 0 },
                 mandobs: [], mandobTotal: 0, profit: null };
      }
      return aggregate(sel);
    },

    get currency() { return (this.data && this.data.currency) || "ج.م"; },
    get maxShare() {
      const v = this.view;
      return (v && v.mandobs.length) ? Math.max(...v.mandobs.map(m => m.share)) : 0;
    },

    pref(key) {
      const p = this.data && this.data.prefs;
      return !p || p[key] !== false; // default: show
    },
    monthName(m) { return String(m); },
    money(v) { return new Intl.NumberFormat("en-US", { maximumFractionDigits: 0 }).format(Math.round(v || 0)); },
    pct(v) { return new Intl.NumberFormat("en-US", { maximumFractionDigits: 1 }).format(v || 0) + "%"; },
    profitVal(row) {
      const v = (this.view && this.view.profit) ? (this.view.profit[row.k] || 0) : 0;
      return row.pct ? this.pct(v) : (this.money(v) + " " + this.currency);
    },
    barW(share) { return this.maxShare > 0 ? Math.max(4, Math.round(share / this.maxShare * 100)) + "%" : "0%"; },

    subtitle() {
      if (!this.data) return "";
      return this.data.branch ? ("الفرع: " + this.data.branch) : "كل الفروع";
    },
    periodLabel() {
      if (this.selYear === "all") return "كل الفترات";
      if (this.selMonth === "all") return "كل الشهور - " + this.selYear;
      return this.monthName(+this.selMonth) + " - " + this.selYear;
    }
  }));
});
