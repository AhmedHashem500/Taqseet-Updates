/* Service worker: caches the app shell for offline use.
 * Stats data is intentionally NOT cached here — the app fetches it live and
 * keeps its own last-known copy in localStorage (works offline). */
const CACHE = "taqseet-stats-v28";
const SHELL = [
  "./",
  "./index.html",
  "./app.js",
  "./config.js",
  "./styles.css",
  "./cairo.ttf",
  "./alpine.min.js",
  "./manifest.webmanifest",
  "./icon-192.png",
  "./icon-512.png"
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  // Always go to the network for the live stats fetch (never serve a stale response):
  // the Cloudflare Worker gateway (*.workers.dev, or any /stats endpoint) + old GitHub hosts.
  if (url.hostname.endsWith(".workers.dev") || url.pathname.endsWith("/stats")
      || url.hostname === "api.github.com" || url.hostname === "raw.githubusercontent.com") return;

  // Cross-origin (Alpine CDN, stable/versioned): cache-first.
  if (url.origin !== self.location.origin) {
    e.respondWith(
      caches.match(req).then((hit) =>
        hit || fetch(req).then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
          return res;
        })
      )
    );
    return;
  }

  // Same-origin app shell: network-first (always fresh when online), cache fallback offline.
  e.respondWith(
    fetch(req).then((res) => {
      const copy = res.clone();
      caches.open(CACHE).then((c) => c.put(req, copy));
      return res;
    }).catch(() => caches.match(req))
  );
});
